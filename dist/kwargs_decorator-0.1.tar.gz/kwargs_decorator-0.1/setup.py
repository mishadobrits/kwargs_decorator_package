from setuptools import setup, find_packages

setup(
    name='kwargs_decorator',
    version='0.1',
    packages=[],
    license='MIT',
    description='Provides more flexible usage of kwargs in python function',
    author='Misha Dobritsyn',
)